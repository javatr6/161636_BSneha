package adminlogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	
	private WebDriver webdriver;
	private WebElement element ;
	
	@Before
	public void setup() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\data\\chromedriver.exe");
		webdriver = new ChromeDriver();
		
	}
	
	@Given("^Open admin login page$")
	public void open_admin_login_page() throws Throwable {
		webdriver.get("http://localhost:8083/BusPassRequest/pages/index1.html?admin=Admin");
	    
	}

	@Given("^provide username and password$")
	public void provide_username_and_password() throws Throwable {
	    webdriver.findElement(By.name("username")).sendKeys("tom");
	    webdriver.findElement(By.name("password")).sendKeys("tom123");
	    
	}

	@When("^valid username and password$")
	public void valid_username_and_password() throws Throwable {
		element =  webdriver.findElement(By.name("login"));
	   element.submit();
	   
	}

	@Then("^navigate to main page$")
	public void navigate_to_main_page() throws Throwable {
		webdriver.navigate().to("http://localhost:8083/BusPassRequest/pages/menu.html");
	}

}
