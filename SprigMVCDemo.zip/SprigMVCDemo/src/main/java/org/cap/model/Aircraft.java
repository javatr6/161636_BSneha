package org.cap.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Aircraft {
	@Id
	@GeneratedValue
private String aircraftId;
	private int maxCrusing;
	private int minCrusing;
	@ManyToMany
	@JoinTable(name="pilot_aircraft",joinColumns= {@JoinColumn(name="aircraftId")},
	inverseJoinColumns= {@JoinColumn(name="pilotId")})
	private List<Pilot> pilots=new ArrayList<>();
	public Aircraft() {
		super();
	}
	public Aircraft(String aircraftId, int maxCrusing, int minCrusing) {
		super();
		this.aircraftId = aircraftId;
		this.maxCrusing = maxCrusing;
		this.minCrusing = minCrusing;
	}
	public String getAircraftId() {
		return aircraftId;
	}
	public void setAircraftId(String aircraftId) {
		this.aircraftId = aircraftId;
	}
	public int getMaxCrusing() {
		return maxCrusing;
	}
	public void setMaxCrusing(int maxCrusing) {
		this.maxCrusing = maxCrusing;
	}
	public int getMinCrusing() {
		return minCrusing;
	}
	public void setMinCrusing(int minCrusing) {
		this.minCrusing = minCrusing;
	}
	@Override
	public String toString() {
		return "Aircraft [aircraftId=" + aircraftId + ", maxCrusing=" + maxCrusing + ", minCrusing=" + minCrusing + "]";
	}
	
	

}
