package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.Product;

public interface IproductDao {
	
	public List<Product> getAllProducts();

	public List<Product> deleteProduct(int productId);

	public List<Product> addProducts(Integer productId,String productName);
	
	public Product findProducts(Integer productId);

	public List<Product> updateProducts(Integer productId, String productName);

}
