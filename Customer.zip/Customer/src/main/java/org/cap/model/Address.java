package org.cap.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Address {
	
	@Id
	private int addressId;
	private String address;
	
	@OneToOne
	@JoinColumn(name = "custfk")
	private Customer customer;
	
	

	public Address(int addressId, String address, Customer customer) {
		super();
		this.addressId = addressId;
		this.address = address;
		this.customer = customer;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", address=" + address + ", customer=" + customer + "]";
	}
	
	

}
