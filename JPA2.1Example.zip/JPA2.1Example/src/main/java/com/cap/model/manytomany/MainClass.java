package com.cap.model.manytomany;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		 EntityManager entityManager = emf.createEntityManager();
		 EntityTransaction transaction = entityManager.getTransaction();
		 
		 transaction.begin();
		 
		 Events java = new Events();
		 java.setEventId("101_JAVA");
		 java.setEventName("JAVA");
		 java.setDateOfEvent(LocalDate.of(2018, 9, 25));
		 
		 Events oracle= new Events();
		 oracle.setEventId("221_ORACLE");
		 oracle.setEventName("ORACLE");
		 oracle.setDateOfEvent(LocalDate.now());
		 
		 Events dotnet = new Events();
		 dotnet.setEventId("333_DOTNET");
		 dotnet.setEventName("DOTNET");
		 dotnet.setDateOfEvent(LocalDate.now());
		 
		 Delegates tom = new Delegates(1,"tom");
		 Delegates jack = new Delegates(12,"jack");
		 Delegates tom1 = new Delegates(19,"tom1");
		 Delegates tom2 = new Delegates(16,"tom2");
		 Delegates tom3 = new Delegates(14,"tom3");
		 
		 tom.getEvents().add(java);
		 tom.getEvents().add(oracle);
		 tom.getEvents().add(dotnet);
		 
		 jack.getEvents().add(java);
		 jack.getEvents().add(oracle);
		 
		 tom2.getEvents().add(java);
		 tom2.getEvents().add(oracle);
		 //tom.getEvents().add(dotnet);

		 tom1.getEvents().add(java);
		 tom1.getEvents().add(oracle);
		 tom1.getEvents().add(dotnet);
		 
		  entityManager.persist(tom);
		  entityManager.persist(tom1);
		  entityManager.persist(tom2);
		  entityManager.persist(tom3);
		  entityManager.persist(jack);
		  
		  entityManager.persist(java);
		  entityManager.persist(oracle);
		  entityManager.persist(dotnet);
		  
		 transaction.commit();
		 entityManager.close();
		
	}

}
