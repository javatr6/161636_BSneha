package org.cap.model.inheritance;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public class Project {
	
	@Id
	private int projectId;
	private String projectName;
	private LocalDate dateOfProject;
	
	public LocalDate getDateOfProject() {
		return dateOfProject;
	}
	public void setDateOfProject(LocalDate dateOfProject) {
		this.dateOfProject = dateOfProject;
	}
	public Project() {
		super();
	}
	public Project(int projectId, String projectName) {
		super();
		this.projectId = projectId;
		this.projectName = projectName;
	}
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", projectName=" + projectName + "]";
	}
	
	

}
