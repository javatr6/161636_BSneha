package org.cap.service;

import org.cap.dao.ILoginDAO;
import org.cap.dao.LoginDAO;
import org.cap.model.LoginBean;

public class LoginServiceImpl implements ILoginService {
	ILoginDAO loginDAO = new LoginDAO();
	@Override
	public boolean checkUser(LoginBean loginBean) {
		return loginDAO.checkUser(loginBean);
	}

}
