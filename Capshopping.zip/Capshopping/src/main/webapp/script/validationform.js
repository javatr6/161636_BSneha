function validateform(){
	
	var flag = false;
	var username = form1.username.value;
	var password = form1.upassword.value;
	//var splchar = "!@#$%^&*()_-+={}[]<>,.';:~|?"
		
	if((username == "")|| (username == null)){
		document.getElementById('userNameErrMsg').innerHTML="* Please enter user Name"
			flag=false;
		}
	else{
		if(password == ""||password == null)
			{
				document.getElementById('passwordErrMsg').innerHTML="* Please enter user password";
					flag=false;
				document.getElementById('userNameErrMsg').innerHTML=""
					flag=false;
			}else{
				flag =true;
			}
	}
	
	if(username.length<5){
		document.getElementById('userNameErrMsg').innerHTML="* user Name should be of minimum 5 characters"
			flag=false
	}
	/*if(username!="" && username.length>=5)
	{
		var len = username.length;
		for(var i=0; i<len; i++)
		{
			for(splchar.indexOf(username.charAt(i))! = -1))
			{
			document.getElementById('userNameErrMsg').innerHTML="* user Name should not contain specila characters"
				flag = false;
			}
		}
	}*/
	//code for password validation
	if(password.length<4){
		document.getElementById('passwordErrMsg').innerHTML="* Please  password must contain 4 characters";
		flag=false;
	}
	return flag;
}